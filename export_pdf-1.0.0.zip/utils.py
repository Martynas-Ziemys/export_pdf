import bpy
import mathutils
import os
import PyOpenColorIO as OCIO
import subprocess
import sys

def open_file(path):
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform.startswith("darwin"):
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])

def scale_increment(self, context):
    if self.export_scale > 4 and self.export_scale % 5 != 0:
        self.export_scale = round(self.export_scale / 5) * 5

def ensure_custom_properties(o): 
    if "stroke_width" not in o:
        o["stroke_width"] = 0.01
        id_props = o.id_properties_ui("stroke_width")
        id_props.update(
            description="Width of exported stroke", 
            min=0.0, 
            max=10.0, 
            default=0.01,
        )
    if "stroke_color" not in o:
        o["stroke_color"] = [0.0, 0.0, 0.0, 1.0]
        id_props = o.id_properties_ui("stroke_color")
        id_props.update(
            description="Color of exported stroke", 
            subtype="COLOR", 
            default=[0.0, 0.0, 0.0, 1.0], 
            min=0, 
            max=1,
        )

def get_material_color(mat): 
    default = list(mat.diffuse_color)
    try:                
        n = sorted(
            [n for n in mat.node_tree.nodes 
            if n.type == "OUTPUT_MATERIAL" 
            and n.inputs['Surface'].links], 
            key=lambda x: x.is_active_output
        )[-1].inputs['Surface'].links[0].from_node
    except IndexError:
        return default
    def col_or_link_rgb(socket):
        if socket.is_linked:
            if socket.links[0].from_node.type == 'RGB':
                return list(socket.links[0].from_node.outputs[0].default_value)
            return default
        return list(socket.default_value)
    def get_node_color(node):
        if node.type in ['EMISSION', 'BSDF_DIFFUSE']:
            return col_or_link_rgb(node.inputs[0]) 
        if node.type == 'BSDF_TRANSPARENT':
            return list(col_or_link_rgb(node.inputs[0]))[:3] + [0.0]
        if node.type == 'BSDF_PRINCIPLED':
            alpha = node.inputs['Alpha'].default_value
            if node.inputs['Emission Strength'].default_value >= 1:
                return col_or_link_rgb(node.inputs['Emission Color'])[:3] + [alpha]
            return col_or_link_rgb(node.inputs['Base Color'])[:3] + [alpha]
        if node.type == 'RGB':
            return list(node.outputs[0].default_value)
        if node.type == 'MIX_SHADER':
            if node.inputs[0].is_linked:
                return default
            f = node.inputs[0].default_value
            colors = []
            for s in range(1, 3): 
                socket = node.inputs[s]
                if socket.is_linked:
                    linked_node = socket.links[0].from_node
                    colors.append(get_node_color(linked_node))
                else:
                    colors.append([0.0, 0.0, 0.0, 1.0])
            return list(mathutils.Vector(colors[0]).lerp(mathutils.Vector(colors[1]), f))
        return default
    return get_node_color(n)


class OCIOColorConverter:
    def __init__(self, scene=None):
        colormanagement_dir = os.path.join(bpy.utils.resource_path('LOCAL'), "datafiles", "colormanagement")
        config_path = os.path.join(colormanagement_dir, "config.ocio")
        if not os.path.exists(config_path):
            config_path = os.path.join(bpy.utils.resource_path('USER'), "datafiles", "colormanagement", "config.ocio")
        config = OCIO.Config.CreateFromFile(config_path)
        transform_list = OCIO.GroupTransform()
        look = scene.view_settings.look
        if look and look != "None":
            look_transform = OCIO.LookTransform()
            look_transform.setSrc("scene_linear")
            look_transform.setDst("scene_linear")
            look_transform.setLooks(look)
            transform_list.appendTransform(look_transform)
        display_transform = OCIO.DisplayViewTransform()
        display_transform.setSrc("scene_linear")
        display_transform.setDisplay(scene.display_settings.display_device)
        display_transform.setView(scene.view_settings.view_transform)
        transform_list.appendTransform(display_transform)
        processor = config.getProcessor(transform_list)
        self.cpu_processor = processor.getDefaultCPUProcessor()

    def to_rgba_255(self, linear_color):
        rgb = list(linear_color[:3])
        a = linear_color[3]
        transformed = self.cpu_processor.applyRGB(rgb) + [a]
        return [round(min(max(v, 0.0), 1.0) * 255) for v in transformed]


def boundary_loops(boundary_edges):
    edge_set = set(boundary_edges)
    adj = {}
    for edge in edge_set:
        v0, v1 = edge.verts
        adj.setdefault(v0, []).append((v1, edge))
        adj.setdefault(v1, []).append((v0, edge))
    loops = []
    visited_edges = set()
    for start_edge in edge_set:
        if start_edge in visited_edges:
            continue
        v0, v1 = start_edge.verts
        loop_verts = [v0]
        current_vert = v1
        current_edge = start_edge
        visited_edges.add(current_edge)
        valid_loop = True
        while current_vert != v0:
            loop_verts.append(current_vert)
            next_candidates = [
                (nxt_v, e) for nxt_v, e in adj.get(current_vert, [])
                if e not in visited_edges
            ]
            if not next_candidates:
                valid_loop = False
                break
            next_v, current_edge = next_candidates[0]
            visited_edges.add(current_edge)
            current_vert = next_v
        if valid_loop and len(loop_verts) >= 3:
            loops.append(loop_verts)
    return loops

