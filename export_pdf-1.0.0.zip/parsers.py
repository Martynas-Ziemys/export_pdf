import bpy
import os
import mathutils
import math
import bmesh
from .utils import *

def parse_single_instance(instance, depsgraph, bounds, col_convert, text_as_mesh, frame_primitives):
    orig_obj = instance.object.original
    matrix_world = instance.matrix_world.copy()
    eval_obj = instance.object
    if orig_obj.type == 'CURVE':
        if eval_obj.type == 'MESH':
            return
        frame_primitives.extend(parse_curve(eval_obj, bounds, depsgraph, col_convert, matrix_world))
    elif orig_obj.type == 'FONT':
        if text_as_mesh:
            eval_obj["stroke_width"] = 0 
            frame_primitives.extend(parse_mesh(eval_obj, bounds, depsgraph, col_convert, matrix_world))
        else:
            if eval_obj.type == 'MESH':
                return
            frame_primitives.extend(parse_text(eval_obj, bounds, depsgraph, col_convert, matrix_world))
    elif orig_obj.type == 'MESH':
        if eval_obj.type == 'MESH':
            frame_primitives.extend(parse_mesh(eval_obj, bounds, depsgraph, col_convert, matrix_world))
    elif orig_obj.type == 'EMPTY' and orig_obj.empty_display_type == 'IMAGE':
        frame_primitives.extend(parse_empty_image(eval_obj, bounds, matrix_world))

def parse_mesh(o, bounds, depsgraph, col_convert, matrix_world):
    mesh_primitives = []
    eval_o = o.evaluated_get(depsgraph)
    mesh = eval_o.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    non_manifold_edges = [e for e in bm.edges if len(e.link_faces) > 2]
    if non_manifold_edges:
        bmesh.ops.split_edges(bm, edges=non_manifold_edges)
    raw_stroke_color = list(o.get("stroke_color", [0.0, 0.0, 0.0, 1.0]))
    stroke_width = o.get("stroke_width", 0.01)
    stroke_color_rgba = col_convert.to_rgba_255(raw_stroke_color)
    world_coords = {v: matrix_world @ v.co for v in bm.verts}
    transformed_coords = {
        v: (
            world_coords[v].x - bounds["min_x"],
            bounds["max_y"] - world_coords[v].y
        )
        for v in bm.verts
    }
    material_groups = {}
    for face in bm.faces:
        material_groups.setdefault(face.material_index, []).append(face)
    for mat_idx, faces in material_groups.items():
        raw_mat_color = [1, 1, 1, 1.0]
        if eval_o.material_slots:
            if eval_o.material_slots[mat_idx].material:
                raw_mat_color = get_material_color(eval_o.material_slots[mat_idx].material)
        face_color_rgba = col_convert.to_rgba_255(raw_mat_color) 
        unvisited = set(faces)
        while unvisited:
            seed = unvisited.pop()
            island_faces = {seed}
            stack = [seed]
            while stack:
                face = stack.pop()
                for edge in face.edges:
                    for linked_face in edge.link_faces:
                        if (
                            linked_face.material_index == mat_idx
                            and linked_face in unvisited
                        ):
                            unvisited.remove(linked_face)
                            island_faces.add(linked_face)
                            stack.append(linked_face)
            island_verts = {v for face in island_faces for v in face.verts}
            z = sum(world_coords[v].z for v in island_verts) / len(island_verts)
            fill_boundary_edges = set()
            for face in island_faces:
                for edge in face.edges:
                    if edge.is_boundary:
                        fill_boundary_edges.add(edge)
                        continue
                    island_links = 0
                    for linked_face in edge.link_faces:
                        if linked_face in island_faces:
                            island_links += 1
                    if island_links == 1:
                        fill_boundary_edges.add(edge)
            loops = boundary_loops(fill_boundary_edges)
            if loops:
                mesh_primitives.append({
                    "type": "fill_mesh",
                    "z_depth": z,
                    "color_rgba_255": face_color_rgba,
                    "paths": [
                        [transformed_coords[v] for v in loop]
                        for loop in loops
                    ]
                })
    if stroke_width > 0.0:
        stroke_loops = boundary_loops(
            {edge for edge in bm.edges if edge.is_boundary}
        )
        for loop in stroke_loops:
            z = max(world_coords[v].z for v in loop)
            mesh_primitives.append({
                "type": "stroke_mesh",
                "z_depth": z + 0.0001,
                "color_rgba_255": stroke_color_rgba,
                "stroke_width": stroke_width,
                "points": [transformed_coords[v] for v in loop],
                "closed": True
            })
    wire_edges = [edge for edge in bm.edges if edge.is_wire]
    additional_strokes = bm.edges.layers.float.get("pdf_stroke")
    additional_colors = bm.edges.layers.float_color.get("pdf_stroke_color")
    if wire_edges or additional_strokes:
        from collections import defaultdict
        edge_data = {}
        stroke_adj = defaultdict(list)
        if additional_strokes:
            for edge in bm.edges:
                w = edge[additional_strokes]
                if w > 0.0:
                    c = col_convert.to_rgba_255(edge[additional_colors]) if additional_colors else stroke_color_rgba
                    edge_data[edge] = (w, tuple(c))
        for edge in wire_edges:
            if edge not in edge_data and stroke_width > 0.0:
                edge_data[edge] = (stroke_width, tuple(stroke_color_rgba))
        for edge in edge_data:
            v0, v1 = edge.verts
            stroke_adj[v0].append((v1, edge))
            stroke_adj[v1].append((v0, edge))
        visited_strokes = set()
        for start_edge, (w, c) in edge_data.items():
            if start_edge in visited_strokes:
                continue
            v0, v1 = start_edge.verts
            path = [v0, v1]
            visited_strokes.add(start_edge)
            for side, curr_v in [("forward", v1), ("backward", v0)]:
                while True:
                    candidates = [
                        (nxt_v, e) for nxt_v, e in stroke_adj[curr_v]
                        if e not in visited_strokes and edge_data.get(e) == (w, c)
                    ]
                    if len(candidates) != 1:
                        break
                    nxt_v, edge_to_add = candidates[0]
                    visited_strokes.add(edge_to_add)
                    if side == "forward":
                        path.append(nxt_v)
                    else:
                        path.insert(0, nxt_v)
                    curr_v = nxt_v
            is_closed = (path[0] == path[-1] and len(path) > 2)
            if is_closed:
                path.pop()
            z = max(world_coords[v].z for v in path)
            mesh_primitives.append({
                "type": "stroke_mesh",
                "z_depth": z + 0.0001,
                "color_rgba_255": list(c),
                "stroke_width": w,
                "points": [transformed_coords[v] for v in path],
                "closed": is_closed
            })
    bm.free()
    eval_o.to_mesh_clear()
    return mesh_primitives

def parse_curve(o, bounds, depsgraph, col_convert, matrix_world):
    curve_primitives = []
    eval_o = o #o.evaluated_get(depsgraph)
    curve_data = eval_o.data
    if not len(curve_data.splines):
        return curve_primitives
    raw_stroke_color = list(o.get("stroke_color", [0.0, 0.0, 0.0, 1.0]))
    stroke_width = o.get("stroke_width", 0.001)
    stroke_color_rgba = col_convert.to_rgba_255(raw_stroke_color)
    matrix = matrix_world
    def transform_pt(v):
        wv = matrix @ v
        return ((wv.x - bounds["min_x"]), (bounds["max_y"] - wv.y)), wv.z
    def get_spline_material_color(mat_idx):
        raw_mat_color = [0.8, 0.8, 0.8, 1.0]
        if eval_o.material_slots:
            if eval_o.material_slots[mat_idx].material:
                raw_mat_color = get_material_color(eval_o.material_slots[mat_idx].material)
        return col_convert.to_rgba_255(raw_mat_color)
    spline_paths = []
    for spline_idx, spline in enumerate(curve_data.splines):
        path_data = {
            "is_bezier": spline.type == 'BEZIER', 
            "closed": spline.use_cyclic_u, 
            "commands": [], 
            "material_index": spline.material_index
        }
        z_sum = 0
        z_count = 0
        if spline.type == 'BEZIER':
            bp = spline.bezier_points
            if len(bp) < 2: continue
            p0, z0 = transform_pt(bp[0].co)
            z_sum += z0
            z_count += 1
            path_data["commands"].append(("M", p0))
            num_points = len(bp)
            for i in range(num_points if spline.use_cyclic_u else num_points - 1):
                next_bp = bp[(i + 1) % num_points]
                h1, _ = transform_pt(bp[i].handle_right)
                h2, _ = transform_pt(next_bp.handle_left)
                co, zc = transform_pt(next_bp.co)
                z_sum += zc
                z_count += 1
                path_data["commands"].append(("C", h1, h2, co))
        else:
            tmp_curve = curve_data.copy()
            for idx in reversed(range(len(tmp_curve.splines))):
                if idx != spline_idx:
                    tmp_curve.splines.remove(tmp_curve.splines[idx])
            tmp_obj = bpy.data.objects.new("tmp_obj", tmp_curve)
            mesh = bpy.data.meshes.new_from_object(tmp_obj)
            if mesh.vertices:
                v_start = mesh.vertices[0]
                p0, z0 = transform_pt(v_start.co)
                z_sum += z0
                z_count += 1
                path_data["commands"].append(("M", p0))
                for v in mesh.vertices[1:]:
                    cx, zc = transform_pt(v.co)
                    z_sum += zc
                    z_count += 1
                    path_data["commands"].append(("L", cx))
            bpy.data.objects.remove(tmp_obj)
            bpy.data.meshes.remove(mesh)
            bpy.data.curves.remove(tmp_curve)
        if path_data["commands"]:
            path_data["z_depth"] = z_sum / z_count
            spline_paths.append(path_data)
    is_filled = False
    if curve_data.dimensions == '2D':
        fill_mode = getattr(curve_data, "fill_mode", 'NONE')
        if fill_mode != 'NONE': 
            is_filled = True
    if spline_paths and is_filled:
        paths_by_material = {}
        for p in spline_paths:
            mat_idx = p["material_index"]
            if mat_idx not in paths_by_material:
                paths_by_material[mat_idx] = []
            paths_by_material[mat_idx].append(p)
        for mat_idx, paths in paths_by_material.items():
            avg_fill_z = sum(p["z_depth"] for p in paths) / len(paths)
            face_color_rgba = get_spline_material_color(mat_idx)
            curve_primitives.append({
                "type": "fill_curve",
                "z_depth": avg_fill_z,
                "color_rgba_255": face_color_rgba,
                "paths": paths
            })
    if stroke_width > 0.0:
        for p_data in spline_paths:
            curve_primitives.append({
                "type": "stroke_curve",
                "z_depth": p_data["z_depth"] + 0.0001,
                "color_rgba_255": stroke_color_rgba,
                "stroke_width": stroke_width,
                "path_commands": list(p_data["commands"]),
                "closed": p_data["closed"]
            })
    return curve_primitives

def parse_text(o, bounds, depsgraph, col_convert, matrix_world):
    text_data = o.data
    raw_text = text_data.body
    local_corners = [mathutils.Vector(corner) for corner in o.bound_box]
    loc_min_x = min(v.x for v in local_corners)
    loc_max_x = max(v.x for v in local_corners)
    loc_min_y = min(v.y for v in local_corners)
    loc_max_y = max(v.y for v in local_corners)
    loc_avg_z = sum(v.z for v in local_corners) / len(local_corners)
    world_scale = matrix_world.to_scale()
    w_local = max(loc_max_x - loc_min_x, 0.001) * world_scale.x
    h_local = max(loc_max_y - loc_min_y, 0.001) * world_scale.y
    local_top_left = mathutils.Vector((loc_min_x, loc_max_y, loc_avg_z))
    world_top_left = matrix_world @ local_top_left
    bbox_world = [matrix_world @ v for v in local_corners]
    z = sum(v.z for v in bbox_world) / len(bbox_world)
    world_euler = matrix_world.to_euler()
    rotation_degrees = math.degrees(world_euler.z)
    raw_mat_color = [0.0, 0.0, 0.0, 1.0]
    if o.material_slots and o.material_slots[0].material:
        raw_mat_color = get_material_color(o.material_slots[0].material)
    color_rgba_255 = col_convert.to_rgba_255(raw_mat_color)
    blender_font = text_data.font
    font_name = blender_font.name
    if font_name == "Bfont Regular":
        font_path = os.path.join(os.path.dirname(__file__), "Bfont.ttf")
    else:
        font_path = bpy.path.abspath(blender_font.filepath) if blender_font.filepath else ""
    return [{
        "type": "text",
        "z_depth": z,
        "text": raw_text,
        "x": world_top_left.x - bounds["min_x"],
        "y": bounds["max_y"] - world_top_left.y,
        "w": w_local,
        "h": h_local,
        "rotation_degrees": rotation_degrees,
        "font_name": font_name,
        "font_path": font_path,
        "color_rgba_255": color_rgba_255,
        "font_size": text_data.size,
        "lines": len(raw_text.strip('\n').splitlines())
    }]

def parse_empty_image(obj, bounds, matrix_world):
    img = obj.data
    if not img.filepath:
        return []
    if not os.path.exists(bpy.path.abspath(img.filepath)):
        return []
    pixel_w, pixel_h = img.size[0], img.size[1]
    if pixel_w == 0 or pixel_h == 0:
        return []
    aspect_ratio = pixel_w / pixel_h
    base_size = obj.empty_display_size
    if aspect_ratio >= 1.0:
        base_w = base_size
        base_h = base_size / aspect_ratio
    else:
        base_w = base_size * aspect_ratio
        base_h = base_size
    matrix_scale = matrix_world.to_scale()
    w = base_w * matrix_scale.x
    h = base_h * matrix_scale.y
    world_loc = matrix_world.to_translation()
    center_x = world_loc.x - bounds["min_x"]
    center_y = bounds["max_y"] - world_loc.y
    rotation_z = matrix_world.to_euler().z
    alpha = obj.color[3] if obj.use_empty_image_alpha else 1.0
    return [{
        "type": "image",
        "z_depth": world_loc.z,
        "filepath": bpy.path.abspath(img.filepath),
        "center_x": center_x,
        "center_y": center_y,
        "w": w,
        "h": h,
        "rotation_z": rotation_z,
        "alpha": alpha
    }]