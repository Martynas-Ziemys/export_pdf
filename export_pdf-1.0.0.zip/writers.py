import fpdf
import os
import math
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen

def append_fill_mesh(pdf, primitive, scale_factor):
    r, g, b, a = primitive["color_rgba_255"]
    with pdf.new_path() as path:
        path.style.fill_color = fpdf.drawing.DeviceRGB(r / 255.0, g / 255.0, b / 255.0)
        path.style.fill_opacity = a / 255.0
        path.style.stroke_color = None
        path.style.intersection_rule = "evenodd"
        for sub_path in primitive["paths"]:
            scaled_points = [(p[0] * scale_factor, p[1] * scale_factor) for p in sub_path]
            path.move_to(scaled_points[0][0], scaled_points[0][1])
            for pt in scaled_points[1:]:
                path.line_to(pt[0], pt[1])
            path.close()

def append_fill_curve(pdf, primitive, scale_factor):
    r, g, b, a = primitive["color_rgba_255"]
    with pdf.new_path() as path:
        path.style.fill_color = fpdf.drawing.DeviceRGB(r / 255.0, g / 255.0, b / 255.0)
        path.style.fill_opacity = a / 255.0
        path.style.stroke_color = None
        path.style.intersection_rule = "evenodd"
        for sub_path in primitive["paths"]:
            if isinstance(sub_path, dict) and "commands" in sub_path:
                if not sub_path.get("closed", False):
                    continue
                for cmd in sub_path["commands"]:
                    if cmd[0] == "M":
                        path.move_to(cmd[1][0] * scale_factor, cmd[1][1] * scale_factor)
                    elif cmd[0] == "L":
                        path.line_to(cmd[1][0] * scale_factor, cmd[1][1] * scale_factor)
                    elif cmd[0] == "C":
                        path.curve_to(
                            cmd[1][0] * scale_factor,
                            cmd[1][1] * scale_factor,
                            cmd[2][0] * scale_factor,
                            cmd[2][1] * scale_factor,
                            cmd[3][0] * scale_factor,
                            cmd[3][1] * scale_factor,
                        )
                path.close()
                
# We need some OPEN continious bezier paths made out of many points for curves, that's why the _out abuse
def append_stroke_mesh(pdf, primitive, scale_factor, scale_pt, page_h_pt):
    r, g, b, a = primitive["color_rgba_255"]
    pdf.set_draw_color(r, g, b)
    pdf.set_line_width(primitive["stroke_width"] * scale_factor)
    pts = primitive["points"]
    if pts:
        with pdf.local_context(stroke_opacity=a / 255):
            pdf._out("1 J 1 j") # round joints, round ends | 0: Butt cap; 1: Round cap; 2: Projecting square cap
            px, py = pts[0][0] * scale_pt, page_h_pt - (pts[0][1] * scale_pt)
            pdf._out(f"{px:.4f} {py:.4f} m")
            for pt in pts[1:]:
                px, py = pt[0] * scale_pt, page_h_pt - (pt[1] * scale_pt)
                pdf._out(f"{px:.4f} {py:.4f} l")
            if primitive["closed"]:
                pdf._out("s")
            else:
                pdf._out("S")

def append_stroke_curve(pdf, primitive, scale_factor, scale_pt, page_h_pt):
    r, g, b, a = primitive["color_rgba_255"]
    pdf.set_draw_color(r, g, b)
    pdf.set_line_width(primitive["stroke_width"] * scale_factor)
    if "path_commands" in primitive:
        with pdf.local_context(stroke_opacity=a / 255):
            pdf._out("1 J 1 j") # round joints, round ends
            for cmd in primitive["path_commands"]:
                if cmd[0] == "M":
                    px, py = cmd[1][0] * scale_pt, page_h_pt - (cmd[1][1] * scale_pt)
                    pdf._out(f"{px:.4f} {py:.4f} m")
                elif cmd[0] == "L":
                    px, py = cmd[1][0] * scale_pt, page_h_pt - (cmd[1][1] * scale_pt)
                    pdf._out(f"{px:.4f} {py:.4f} l")
                elif cmd[0] == "C":
                    hx1, hy1 = cmd[1][0] * scale_pt, page_h_pt - (cmd[1][1] * scale_pt)
                    hx2, hy2 = cmd[2][0] * scale_pt, page_h_pt - (cmd[2][1] * scale_pt)
                    ex, ey = cmd[3][0] * scale_pt, page_h_pt - (cmd[3][1] * scale_pt)
                    pdf._out(f"{hx1:.4f} {hy1:.4f} {hx2:.4f} {hy2:.4f} {ex:.4f} {ey:.4f} c")
            if primitive["closed"]:
                pdf._out("s")
            else:
                pdf._out("S")

def get_multiline_text_bounds(font_path, text_lines):
    try:
        font = TTFont(font_path)
        glyph_set = font.getGlyphSet()
        cmap = font['cmap'].getBestCmap()
        hhea = font['hhea']
        units_per_em = font['head'].unitsPerEm
        baseline_step = hhea.ascent - hhea.descent + hhea.lineGap
        def get_line_bounds(line):
            y_mins, y_maxs = [], []
            for char in line:
                if char.isspace(): continue
                glyph_name = cmap.get(ord(char))
                if glyph_name and glyph_name in glyph_set:
                    pen = BoundsPen(glyph_set)
                    glyph_set[glyph_name].draw(pen)
                    if pen.bounds:
                        y_mins.append(pen.bounds[1])
                        y_maxs.append(pen.bounds[3])
            if not y_mins:
                return 0, 0
            return min(y_mins), max(y_maxs)
        first_line_ymin, first_line_ymax = get_line_bounds(text_lines[0])
        last_line_ymin, last_line_ymax = get_line_bounds(text_lines[-1])
        total_font_span = first_line_ymax + (len(text_lines) - 1) * baseline_step - last_line_ymin
        return first_line_ymax, baseline_step, total_font_span, units_per_em
    except Exception:
        return 800, 1200, 1200 + (len(text_lines) - 1) * 1200, 1000 

def append_text(pdf, primitive, scale_factor):
    r, g, b, a = primitive["color_rgba_255"]
    num_lines = max(int(primitive["lines"]), 1)
    text_content = primitive["text"]
    text_lines = text_content.splitlines()
    x_scaled = primitive["x"] * scale_factor
    y_scaled = primitive["y"] * scale_factor
    w_scaled = primitive["w"] * scale_factor
    h_scaled = primitive["h"] * scale_factor
    font_key = primitive["font_name"]
    font_path = primitive["font_path"]
    rotation_angle = primitive.get("rotation_degrees", 0.0)
    alignment = primitive.get("alignment", "LEFT")
    use_fonttools = False
    if font_path and os.path.exists(font_path):
        use_fonttools = True
        if font_key.lower() not in pdf.fonts:
            try:
                pdf.add_font(font_key, style="", fname=font_path)
            except Exception:
                font_key = "Helvetica"
                use_fonttools = False
    else:
        font_key = "Helvetica"
    if use_fonttools:
        first_ymax, baseline_step, total_font_span, units_per_em = get_multiline_text_bounds(font_path, text_lines[:num_lines])
    else:
        first_ymax, baseline_step, total_font_span, units_per_em = 800, 1200, 1200 + (num_lines - 1) * 1200, 1000
    total_font_span = max(total_font_span, 1)
    final_font_size = (h_scaled * (72.0 / 25.4)) * (units_per_em / total_font_span)
    pdf.set_font(font_key, size=final_font_size)
    line_widths = [pdf.get_string_width(line) if line.strip() else 0.0 for line in text_lines[:num_lines]]
    max_line_width = max(line_widths) if line_widths and max(line_widths) > 0 else 0.0001
    stretching_ratio = (w_scaled / max_line_width) * 100.0
    first_baseline_offset = h_scaled * (first_ymax / total_font_span)
    y_baseline_start = y_scaled + first_baseline_offset
    step_scaled = h_scaled * (baseline_step / total_font_span)
    with pdf.local_context(fill_opacity=a / 255.0):
        pdf.set_text_color(r, g, b)
        pdf.set_stretching(stretching_ratio)
        for i, line_text in enumerate(text_lines[:num_lines]):
            if not line_text.strip():
                continue
            y_baseline = y_baseline_start + (i * step_scaled)
            x_offset = 0.0
            if alignment == "CENTER":
                x_offset = ((max_line_width - line_widths[i]) / 2.0) * (w_scaled / max_line_width)
            elif alignment == "RIGHT":
                x_offset = (max_line_width - line_widths[i]) * (w_scaled / max_line_width)
            final_x = x_scaled + x_offset
            if rotation_angle != 0.0:
                with pdf.rotation(rotation_angle, x=x_scaled, y=y_scaled):
                    pdf.text(final_x, y_baseline, line_text)
            else:
                pdf.text(final_x, y_baseline, line_text)
    pdf.set_stretching(100.0)

def append_image(pdf, primitive, scale_factor):
    img_w, img_h = primitive["w"] * scale_factor, primitive["h"] * scale_factor
    cx, cy = primitive["center_x"] * scale_factor, primitive["center_y"] * scale_factor
    img_x, img_y = cx - (img_w / 2.0), cy - (img_h / 2.0)
    angle_deg = math.degrees(primitive["rotation_z"])
    with pdf.local_context(fill_opacity=primitive["alpha"]):
        if angle_deg != 0.0:
            with pdf.rotation(angle_deg, x=cx, y=cy):
                pdf.image(primitive["filepath"], x=img_x, y=img_y, w=img_w, h=img_h)
        else:
            pdf.image(primitive["filepath"], x=img_x, y=img_y, w=img_w, h=img_h)

def append_pdf_frame(pdf, frame_data, bounds, scale_factor=50.0):
    view_w = bounds["width"] * scale_factor
    view_h = bounds["height"] * scale_factor
    pdf.add_page(format=(view_w, view_h))
    mm_to_pt = 72.0 / 25.4
    scale_pt = scale_factor * mm_to_pt
    page_h_pt = view_h * mm_to_pt
    for primitive in frame_data:
        primitive_type = primitive["type"]
        if primitive_type == "fill_mesh":
            append_fill_mesh(pdf, primitive, scale_factor)
        elif primitive_type == "fill_curve":
            append_fill_curve(pdf, primitive, scale_factor)
        elif primitive_type == "stroke_mesh":
            append_stroke_mesh(pdf, primitive, scale_factor, scale_pt, page_h_pt)
        elif primitive_type == "stroke_curve":
            append_stroke_curve(pdf, primitive, scale_factor, scale_pt, page_h_pt)
        elif primitive_type == "text":
            append_text(pdf, primitive, scale_factor)
        elif primitive_type == "image":
            append_image(pdf, primitive, scale_factor)